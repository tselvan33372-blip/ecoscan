# 🌍 EcoScan Waste Detector - Complete Deployment Guide for Beginners

## Table of Contents
1. [Setup & Prerequisites](#setup--prerequisites)
2. [Getting Hugging Face API Key](#getting-hugging-face-api-key)
3. [Preparing Your Project](#preparing-your-project)
4. [Deploying to Vercel](#deploying-to-vercel)
5. [Configuring Environment Variables](#configuring-environment-variables)
6. [Testing Your Application](#testing-your-application)
7. [Troubleshooting](#troubleshooting)

---

## Setup & Prerequisites

### What You Need
- **GitHub Account** (free): https://github.com (if you don't have one, create one)
- **Vercel Account** (free): https://vercel.com
- **Hugging Face Account** (free): https://huggingface.co
- **Git** installed on your computer (optional but recommended)
- **A code editor** (VS Code recommended): https://code.visualstudio.com

### Step 1: Create a GitHub Account (if you don't have one)
1. Go to https://github.com
2. Click "Sign up"
3. Follow the registration steps
4. Verify your email

### Step 2: Create a Vercel Account
1. Go to https://vercel.com
2. Click "Sign up"
3. Click "Continue with GitHub"
4. Authorize Vercel to access your GitHub account
5. Done! You're ready to deploy

---

## Getting Hugging Face API Key

The AI uses Hugging Face's vision model to identify waste with 90%+ accuracy.

### Step 1: Create Hugging Face Account
1. Go to https://huggingface.co
2. Click "Sign Up"
3. Complete registration and verify email

### Step 2: Get Your API Key
1. After login, click your profile picture (top-right)
2. Select "Settings"
3. Click "Access Tokens" in the left menu
4. Click "New token"
5. Choose "Read" permission
6. Name it "ecoscan-api"
7. Click "Generate a token"
8. **COPY THE TOKEN AND SAVE IT SAFELY** ⚠️ (You'll need it in a few minutes)

---

## Preparing Your Project

### Method 1: Using Git (Recommended for Beginners)

#### Step 1: Create a Folder for Your Project
```bash
# Open Terminal/Command Prompt and run:
mkdir ecoscan-project
cd ecoscan-project
```

#### Step 2: Initialize Git
```bash
git init
```

#### Step 3: Create a Simple Server File (vercel.json)
Create a new file called `vercel.json` in your project folder:

```json
{
  "version": 2,
  "builds": [
    {
      "src": "package.json",
      "use": "@vercel/static-build",
      "config": {
        "distDir": "."
      }
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "index.html"
    }
  ]
}
```

#### Step 4: Create a package.json File
Create a file called `package.json`:

```json
{
  "name": "ecoscan",
  "version": "1.0.0",
  "scripts": {
    "dev": "npx http-server",
    "build": "echo 'Build complete'"
  }
}
```

#### Step 5: Add Your HTML File
1. Copy the `ecoscan-waste-detector.html` file into your project folder
2. Rename it to `index.html`

#### Step 6: Create .gitignore
Create a file called `.gitignore`:

```
node_modules/
.DS_Store
.env
.env.local
```

#### Step 7: Commit Your Code
```bash
git add .
git commit -m "Initial commit: EcoScan waste detector"
```

### Method 2: Without Git (For Windows Users Without Git Installed)

1. Create a folder: `C:\Users\YourName\ecoscan-project`
2. Inside it, create these files:
   - `index.html` (your waste detector code)
   - `vercel.json` (config file)
   - `package.json` (dependencies)

---

## Deploying to Vercel

### Step 1: Upload to GitHub

#### Option A: Using Git (Command Line)
```bash
# In your project folder terminal:
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/ecoscan.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username.

#### Option B: Using GitHub Website
1. Go to https://github.com/new
2. Name your repository: `ecoscan`
3. Click "Create repository"
4. Follow the "upload files" option shown on GitHub
5. Drag and drop your files into the browser

### Step 2: Import Project to Vercel

1. Go to https://vercel.com/dashboard
2. Click "Add New..." → "Project"
3. Click "Import Git Repository"
4. Find your `ecoscan` repository
5. Click "Import"
6. Configure project:
   - Framework Preset: "Other"
   - Build Command: (leave empty)
   - Output Directory: "." (current directory)
7. Click "Deploy"

**Your app will deploy in 30-60 seconds!** 🚀

### Step 3: Get Your Live URL
After deployment completes:
1. You'll see a success message
2. Your site URL will be something like: `https://ecoscan-abc123.vercel.app`
3. Click the URL to visit your live website

---

## Configuring Environment Variables

### Why Environment Variables?
Keep your API key secret and not visible in your code!

### Step 1: Create an Environment Variable in Vercel
1. In your Vercel project dashboard, go to "Settings"
2. Click "Environment Variables" (left menu)
3. Add a new variable:
   - **Name:** `HF_API_KEY`
   - **Value:** Paste your Hugging Face API key
   - Click "Save"

### Step 2: Update Your Code
In your `index.html`, find this line:
```javascript
const HF_API_KEY = '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';
```

Replace it with:
```javascript
const HF_API_KEY = process.env.HF_API_KEY || 'your-fallback-key';
```

### Step 3: Redeploy
1. Make the change above
2. Commit and push to GitHub:
   ```bash
   git add .
   git commit -m "Add environment variable support"
   git push
   ```
3. Vercel will automatically redeploy

---

## Testing Your Application

### Test 1: Basic Functionality
1. Open your Vercel URL
2. Click "Start Scanning"
3. Upload a test image (try images from Google Images)
4. Check if it correctly identifies biodegradable vs non-biodegradable waste

### Test 2: AI Accuracy
Try these items:
- ✅ **Biodegradable**: Apple, Banana peel, Leaves, Paper
- ❌ **Non-biodegradable**: Plastic bottle, Metal can, Glass, Styrofoam

### Test 3: Mobile Responsiveness
1. Open your site on a phone or tablet
2. Test the upload functionality
3. Verify buttons and text are readable

---

## Troubleshooting

### Problem 1: API Key Not Working
**Error:** "Authorization failed" or "API error"

**Solution:**
1. Check your Hugging Face API key is correct
2. Make sure it has "Read" permissions
3. Verify it's added to Vercel environment variables
4. Restart Vercel deployment: Settings → Deployments → Redeploy

### Problem 2: Images Not Uploading
**Error:** "CORS error" or "Network error"

**Solution:**
1. Check your internet connection
2. Try a different image file (under 10MB)
3. Clear browser cache (Ctrl+Shift+Delete on Windows, Cmd+Shift+Delete on Mac)
4. Try a different browser

### Problem 3: Slow AI Response
**Normal:** First request takes 5-10 seconds, subsequent requests are faster

**Solution:**
- The first time Hugging Face loads the model, it takes time
- Subsequent requests are cached and faster
- Be patient on first scan!

### Problem 4: Vercel Deployment Failed
**Error:** "Build failed" message

**Solution:**
1. Check your `package.json` is valid JSON (no syntax errors)
2. Check your `vercel.json` configuration
3. Make sure `index.html` is in the root directory
4. Try redeploying: Vercel Dashboard → Deployments → Redeploy

### Problem 5: White Blank Page
**Error:** Nothing loads on the site

**Solution:**
1. Check browser console for errors (F12 → Console tab)
2. Clear browser cache
3. Check that your HTML file is named `index.html`
4. Verify all image links are correct

---

## Performance & Optimization Tips

### For Better Performance:
1. **Optimize images before uploading** (use https://tinypng.com)
2. **Use Chrome DevTools** to check performance: F12 → Lighthouse
3. **Test on 3G network** to see real-world performance
4. **Monitor Vercel Analytics**: Settings → Analytics

### For Better Accuracy:
1. **Use clear images** with good lighting
2. **Avoid blurry photos**
3. **Center the waste item** in the frame
4. **Use uniform background** if possible

---

## Next Steps: Add More Features

### Feature 1: Database for Logging
Add Firebase to log user scans:
- https://firebase.google.com (free)

### Feature 2: User Authentication
Add user login with Supabase:
- https://supabase.com (free)

### Feature 3: Advanced Analytics
Track environmental impact:
- Use Google Analytics: https://analytics.google.com

### Feature 4: Mobile App
Convert to PWA or React Native:
- Expo: https://expo.dev

---

## Production Checklist

Before sharing your site publicly:

- [ ] Update HTML title and description
- [ ] Add your logo and favicon
- [ ] Test on mobile devices
- [ ] Enable HTTPS (automatic with Vercel ✓)
- [ ] Add privacy policy
- [ ] Test API with real images
- [ ] Set up error tracking (Sentry)
- [ ] Monitor uptime (UptimeRobot)

---

## Support Resources

- **Vercel Docs**: https://vercel.com/docs
- **Hugging Face Docs**: https://huggingface.co/docs
- **GitHub Help**: https://docs.github.com
- **Web Development**: https://developer.mozilla.org

---

## FAQ

**Q: Is my API key secure?**
A: Yes! Use environment variables, never commit API keys to GitHub.

**Q: Can I use a custom domain?**
A: Yes! Vercel → Settings → Domains (paid feature, or use free .vercel.app)

**Q: How much does it cost?**
A: Completely free! Vercel free tier includes unlimited deployments.

**Q: Can I modify the design?**
A: Yes! Edit the CSS in the `<style>` section. No coding knowledge needed!

**Q: How accurate is the AI?**
A: 90%+ for clear images. Accuracy depends on image quality.

**Q: What if I want to add a database?**
A: Use Firebase, Supabase, or MongoDB Atlas (all free tier available).

---

## Congratulations! 🎉

Your EcoScan waste detector is now live on the internet!
Share your URL with friends and help them become eco-warriors.

**Your live URL**: `https://your-site.vercel.app`

**Keep the planet green!** 🌍♻️
